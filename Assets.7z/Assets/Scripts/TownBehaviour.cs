using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TownBehaviour : MonoBehaviour
{
    public Tilemap    borderTilemap;
    [SerializeField] private Tile borderTile;

    public void ExtendBorders(Vector3Int center, int radius)
    {
        for(int x = center.x - radius; x < center.x + radius; x++)
        {
            for(int y = center.y - radius; y < center.y + radius; y++)
            {
                borderTilemap.SetTile(new Vector3Int(x, y, 0), borderTile);
            }
        }
    }
}
