using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Tilemaps;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private Tilemap tilemap;
    [SerializeField] private Tilemap borderTilemap;
    [SerializeField] private Vector3 moveModifier;
    [SerializeField] private LayerMask layersToInterract;

    [SerializeField] private Image   environmentImage;
    [SerializeField] private Sprite[] environmentSpriteVariants;
    [SerializeField] private Image   npcImage; 
    [SerializeField] private Sprite[] npcSpriteVarians;

    [SerializeField] private TileBase[] tilesToCheck; 


     
    private Vector3[] moveVariants = {Vector3.right, Vector3.up, Vector3.down, Vector3.left}; 
    private                  bool initialized;

    public void Init() => initialized = true;
    public void Move()
    {
        Vector3 targetDir = transform.position + moveVariants[Random.Range(0, moveVariants.Length)];
        if(tilemap.GetTile(Vector3Int.FloorToInt(targetDir)) != null)
        {
            transform.position = targetDir;
        }
        else
        {
            transform.position = targetDir * -1;
        }
        SetImageByTile();
    }

    private TileBase CheckTile(Vector3Int position)
    {
        return tilemap.GetTile(position);
    }

    private TileBase CheckBorderTile(Vector3Int position)
    {
        return borderTilemap.GetTile(position);
    }

    public void SetImageByTile()
    {
        TileBase tile = CheckTile(Vector3Int.FloorToInt(transform.position));
        environmentImage.sprite = environmentSpriteVariants[GetTileId(tile)];
        CheckForMan(transform.position);
    }

    private void CheckForMan(Vector3 position)
    {
        Collider[] colliders = Physics.OverlapSphere(position, 0.5f, layersToInterract);
        if(colliders.Length > 0 && colliders[0].TryGetComponent(out Man man))
        {
            npcImage.sprite = GetSpriteByManProps(man);
        }
        else
        {
            npcImage.sprite = npcSpriteVarians[4];
        }
    }

    private Sprite GetSpriteByManProps(Man man)
    {
        if(man.kid)
        {
            if(man.isMale)
            {
                return npcSpriteVarians[0]; 
            }
            else if(!man.isMale)
            {
                return npcSpriteVarians[1];
            }
        }
        else
        {
            if(man.isMale)
            {
                return npcSpriteVarians[2]; 
            }
            else if(!man.isMale)
            {
                return npcSpriteVarians[3];
            }
        }
        return npcSpriteVarians[4];
    }

    private int GetTileId(TileBase tile)
    {
        for(int i = 0; i < tilesToCheck.Length; i++)
        {
            if(tile == tilesToCheck[i])
            {
                return i;
            }
        }
        return 0;
    }
}
