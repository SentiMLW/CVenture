using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections;
using System.Collections.Generic;

public class Man : MonoBehaviour{

    // The speed of the NPC movement
    public float speed = 1f;
    [SerializeField] private GameObject manPref;
    [SerializeField] private LayerMask layersToInterract;
    private int restCount;
    private bool talking;
    [SerializeField] private Man currentTalk; 
    public bool  kid;
    [SerializeField] private GameObject gruz; 
    [SerializeField] private HouseBehaviour houseBehaviour;
    [SerializeField] private GameObject messageBox; 

    // The parent point of the NPC
    public Transform parentPoint;

    // The tree tile for the tilemap
    public Tile treeTile;
    public Tile emptyTile;

    // The tilemap for the world
    public Tilemap tilemap;

    // The current state of the NPC
    private enum State {
        Idle,
        Moving,
        Chopping,
        Returning,
        Rest,
        TalkToOtherNPC,
        MakeLove
    }

    // The current state of the NPC
    private State state = State.Idle;

    // The current target position of the NPC
    private Vector3 targetPosition;

    // The current target tile of the NPC
    private Vector3Int targetTile;

    // The distance threshold for reaching the target position
    private float distanceThreshold = 0.1f;

    private int   chatMoves;

    // The coroutine for moving the NPC
    private IEnumerator moveCoroutine;
    private bool choppedTree;
    // Update is called once per frame

    private Vector3 predPos;
    private int     ignoreCount;

    private bool choppedTreeOnce;
    private int choppedTreeTillReset;

    public bool isMale;
    private int  tillAdult;
    private int  tillMakeLove;

    [SerializeField] private Sprite[] sprites;
    private SpriteRenderer sprRend; 
    public void Init(bool male, bool isKid, Tilemap _tilemap)
    {
        sprRend = GetComponent<SpriteRenderer>();
        tilemap = _tilemap;
        isMale = male;
        kid = isKid;
        houseBehaviour.tilemap = tilemap;
        if(male && isKid)
        {
            sprRend.sprite = sprites[0];
        }
        else if(male)
        {
            sprRend.sprite = sprites[1];
        }
        else if(!male && isKid)
        {
            sprRend.sprite = sprites[2];
        }
        else
        {
            sprRend.sprite = sprites[3];
        }
    }

    public void Step() {
        // Handle the NPC behaviour based on the current state
        messageBox.SetActive(false);
        if(kid && tillAdult < 20)
        {
            state = State.Moving;
            tillAdult++;
            Debug.Log($"Till adult{tillAdult}");
        }
        else if(tillAdult >= 20)
        {
            Init(isMale, false, tilemap);
        }
        switch (state) {
            case State.Idle:
            float chance = Random.Range(0.0f, 1.0f);
                if(chance >= 0.6f)
                {    // Choose a random direction to move
                    ChooseDirection();

                    // Start the coroutine for moving the NPC
                    moveCoroutine = MoveToTarget();
                    StartCoroutine(moveCoroutine);

                    // Change the state to moving
                    state = State.Moving;
                }
                else if(chance >= 0.07f){
                    restCount = Random.Range(13, 19);
                    state = State.Rest;
                }
                else{
                    if(tillMakeLove < 3)
                    {
                        tillMakeLove++;
                    }
                    else{
                        state = State.MakeLove;
                        tillMakeLove = 0;
                    }
                }
                break;
            case State.Moving:
                // Check if the NPC has reached the target position
                if (HasReachedTarget()) {
                    // Stop the coroutine for moving the NPC
                    StopCoroutine(moveCoroutine);

                    // Find the nearest tree tile that is one tile away
                    FindNearestTree();

                    // Check if the NPC has found a tree tile
                    if (targetTile != Vector3Int.zero) {
                        // Set the target position to the tree tile position
                        Vector3 tempPos = tilemap.CellToWorld(targetTile);
                        targetPosition = new Vector3(tempPos.x + 0.5f, tempPos.y + 0.5f, 0);

                        // Start the coroutine for moving the NPC
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);

                        // Change the state to chopping
                        state = State.Chopping;
                    }
                    else {
                        // Choose a random direction to move
                        ChooseDirection();

                        // Start the coroutine for moving the NPC
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);
                    }
                }
                else {
                        // Choose a random direction to move
                        ChooseDirection();

                        // Start the coroutine for moving the NPC
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);
                    }
                break;
            case State.Chopping:
                if(choppedTreeOnce){
                    // Check if the NPC has reached the target position
                    if (HasReachedTarget()) {
                        // Stop the coroutine for moving the NPC
                        StopCoroutine(moveCoroutine);

                        // Set the target position to the parent point position
                        targetPosition = parentPoint.position;

                        // Start the coroutine for moving the NPC
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);

                        // Change the state to returning
                        state = State.Returning;
                    }
                    else{
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);
                    }
                }
                else
                {
                    state = State.Idle;
                }
                break;
            case State.Returning:
                // Check if the NPC has reached the target position
                if (HasReachedTarget()) {
                    // Stop the coroutine for moving the NPC
                    StopCoroutine(moveCoroutine);
                    if(choppedTree){
                        houseBehaviour.UpgradeHouse();
                        gruz.SetActive(false);
                        choppedTree = false;
                    }

                    // Change the state to idle
                    state = State.Idle;
                }
                else{
                    moveCoroutine = MoveToTarget();
                    StartCoroutine(moveCoroutine);
                }
                break;
            case State.Rest:
                if(restCount > 0){
                    restCount--;
                    ChooseDirection();

                    // Start the coroutine for moving the NPC
                    moveCoroutine = MoveToTarget();
                    StartCoroutine(moveCoroutine);
                    break;
                }
                else if(Random.Range(0.0f, 1.0f) > 0.5f)
                {
                    ChooseDirection();

                    // Start the coroutine for moving the NPC
                    moveCoroutine = MoveToTarget();
                    StartCoroutine(moveCoroutine);

                    // Change the state to moving
                    state = State.Moving;
                }
                else
                {
                    if(TryFoundingManNear()){

                        // Start the coroutine for moving the NPC
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);

                        // Change the state to moving
                        state = State.TalkToOtherNPC;
                        chatMoves = Random.Range(3, 5);
                    }
                    else
                    {
                        ChooseDirection();

                        // Start the coroutine for moving the NPC
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);

                        // Change the state to moving
                        state = State.Moving;
                    }
                }
                break;
            case State.TalkToOtherNPC:
                if (talking && chatMoves <= 0) {
                        // Stop the coroutine for moving the NPC
                    StopCoroutine(moveCoroutine);
                    messageBox.SetActive(false);

                    // Change the state to idle
                    state = State.Returning;
                    talking = false;
                }
                else if(talking)
                {
                    chatMoves--;
                    messageBox.SetActive(true);
                }
                else{
                    if(TryFoundingManNear())
                    {
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);
                    }
                    else{
                        state = State.Idle;
                    }
                }
                break;
            case State.MakeLove:
                if (talking && chatMoves <= 0) {
                        // Stop the coroutine for moving the NPC
                    StopCoroutine(moveCoroutine);
                    messageBox.SetActive(false);
                    Vector3Int housePos = TryCreateNewPerson();
                    if(housePos != new Vector3Int(-1, -1, 0))
                    {
                        bool male = false;
                        Vector3 housePosWorldSpace = new Vector3(housePos.x + 0.5f, housePos.y + 0.5f, 0);
                        GameObject man = Instantiate(manPref, housePosWorldSpace, Quaternion.identity);
                        Man manComponent = man.GetComponentInChildren<Man>();
                        if(Random.Range(0.0f, 1.0f) >= 0.5)
                        {
                            male = true;
                        }
                        manComponent.Init(male, true, tilemap);
                        StructGeneration.structGenInstance.AddManToAllMen(manComponent);
                    }

                    // Change the state to idle
                    state = State.Returning;
                    talking = false;
                }
                else if(talking)
                {
                    chatMoves--;
                    messageBox.SetActive(true);
                }
                else{
                    if(TryFoundingParthnerNear())
                    {
                        moveCoroutine = MoveToTarget();
                        StartCoroutine(moveCoroutine);
                    }
                    else{
                        state = State.Idle;
                    }
                }
                break;
        }
        Debug.Log(state);
    }

    private Vector3Int TryCreateNewPerson()
    {
        Vector3Int curPos = Vector3Int.FloorToInt(transform.position);
        for(int x = curPos.x - 3; x <= curPos.x + 3; x++)
        {
            for(int y = curPos.y - 3; y <= curPos.y + 3; y++)
            {
                if(CheckForHouse(new Vector3Int(x, y, 0)))
                {
                    return new Vector3Int(x, y, 0);
                }
            }
        }
        return new Vector3Int(-1, -1, 0);
    }

    private bool CheckForHouse(Vector3Int checkPos)
    {
        foreach(Tile tile in houseBehaviour.houseTiles)
        {
            if(tilemap.GetTile(checkPos) == tile)
            {
                return true;
            }
        }
        return false;
    }

    private bool TryFoundingManNear()
    {
        Collider[] men = Physics.OverlapSphere(transform.position, 37, layersToInterract);
        if(men.Length > 0 && men[0].gameObject.TryGetComponent(out Man manComp))
        {
            Vector3 meetPos = Vector3Int.FloorToInt((transform.position + manComp.transform.position) / 2);
            meetPos += new Vector3(0.5f, 0.5f, 0);
            currentTalk = manComp;
            targetPosition = meetPos;
            manComp.Talk(meetPos);
            return true;
        }
        return false;
    }

    private bool TryFoundingParthnerNear()
    {
        Collider[] men = Physics.OverlapSphere(transform.position, 37, layersToInterract);
        if(men.Length > 0 && men[0].gameObject.TryGetComponent(out Man manComp))
        {
            if(manComp.isMale != isMale)
            {   
                Vector3 meetPos = Vector3Int.FloorToInt((transform.position + manComp.transform.position) / 2);
                meetPos += new Vector3(0.5f, 0.5f, 0);
                currentTalk = manComp;
                targetPosition = meetPos;
                manComp.Talk(meetPos);
                return true;
            }
        }
        return false;
    }

    public void Talk(Vector3 posToTalk)
    {
        targetPosition = posToTalk;
        state = State.TalkToOtherNPC;
    }

    // Choose a random direction to move
    private void ChooseDirection() {
        // Get the current position of the NPC
        Vector3 currentPosition = transform.position;

        // Choose a random direction from the four possible directions
        int direction = Random.Range(0, 4);

        // Set the target position based on the direction
        switch (direction) {
            case 0: // Up
                targetPosition = currentPosition + Vector3.up;
                break;
            case 1: // Down
                targetPosition = currentPosition + Vector3.down;
                break;
            case 2: // Left
                targetPosition = currentPosition + Vector3.left;
                break;
            case 3: // Right
                targetPosition = currentPosition + Vector3.right;
                break;
        }
    }

    // Move towards the target position
    private IEnumerator MoveToTarget() {
        Vector3 plusVector = Vector3.zero;
        if(targetPosition.x > transform.position.x)
        {  
            plusVector = Vector3.right;
        }
        else if(targetPosition.x < transform.position.x)
        {
            plusVector = Vector3.left;
        }
        else if(targetPosition.y < transform.position.y)
        {
            plusVector = Vector3.down;
        }
        else if(targetPosition.y > transform.position.y)
        {
            plusVector = Vector3.up;
        }

        if(tilemap.GetTile(Vector3Int.FloorToInt(transform.position + plusVector)) != treeTile 
            && Physics.OverlapSphere(transform.position + plusVector, 0.1f, layersToInterract).Length <= 0)
        {
            transform.position += plusVector;
        }
        else if(Physics.OverlapSphere(transform.position + plusVector, 0.1f, layersToInterract).Length > 0)
        {
            talking = true;
            state = State.TalkToOtherNPC;
            messageBox.SetActive(true);
            if(predPos == transform.position)
            {
                ignoreCount++;
                if(ignoreCount >= 2)
                {
                    transform.position += plusVector;
                    ignoreCount = 0;
                }
            }
        }
        else
        {
        // Stop the coroutine for moving the NPC
            StopCoroutine(moveCoroutine);

            // Chop the tree tile
            tilemap.SetTile(Vector3Int.FloorToInt(transform.position + plusVector), emptyTile);
            choppedTree = true;
            choppedTreeOnce = true;
            choppedTreeTillReset++;
            if(choppedTreeTillReset >= 5)
            {
                choppedTreeOnce = false;
                choppedTreeTillReset = 0;
            }
            gruz.SetActive(true);

            // Set the target position to the parent point position
            targetPosition = parentPoint.position;

            // Start the coroutine for moving the NPC
            moveCoroutine = MoveToTarget();
            StartCoroutine(moveCoroutine);

            // Change the state to returning
            state = State.Returning;
        }
        predPos = transform.position;
        // Wait for one frame
        yield return null;
    }

    // Check if the NPC has reached the target position
    private bool HasReachedTarget() {
        // Calculate the distance to the target position
        float distance = Vector3.Distance(transform.position, targetPosition);

        // Return true if the distance is less than or equal to the distance threshold
        return distance <= distanceThreshold;
    }

    // Find the nearest tree tile that is one tile away
    private void FindNearestTree() {
        // Initialize the nearest tree to null
        targetTile = Vector3Int.zero;

        // Get the current tile of the NPC
        Vector3Int currentTile = tilemap.WorldToCell(transform.position);

        // Loop through the four adjacent tiles
        for (int x = -20; x <= 20; x++) {
            for (int y = -20; y <= 20; y++) {
                // Skip the diagonal tiles
                if (x != 0 && y != 0) {
                    continue;
                }

                // Calculate the tile position
                Vector3Int tilePosition = currentTile + new Vector3Int(x, y, 0);

                // Check if the tile is a tree tile
                if (tilemap.GetTile(tilePosition) == treeTile) {
                    // Set the nearest tree to the tile position
                    targetTile = tilePosition;

                    // Break the loop
                    break;
                }
            }
        }
    }
}
