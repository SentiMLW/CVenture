using UnityEngine;
using UnityEngine.Tilemaps;

public class HouseBehaviour : MonoBehaviour
{
    public int houseLvl = 0;
    private int resoursesRequired = 5;
    private int resourses;
    public Tilemap tilemap;
    public TownBehaviour townBehaviour;
    public Tile[]  houseTiles;  
    public void UpgradeHouse()
    {
        resourses++;
        if(resourses >= resoursesRequired)
        {
            houseLvl++;
            if(townBehaviour != null)
            {
                townBehaviour.ExtendBorders(Vector3Int.FloorToInt(transform.position), houseLvl);
            }
            tilemap.SetTile(Vector3Int.FloorToInt(transform.position), houseTiles[houseLvl]);
            resoursesRequired *= houseLvl + 1;
            resourses = 0;
        }
    }
}
