using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Tilemaps;
using System.Threading.Tasks;

public class MapGeneration : MonoBehaviour
{
    
    // The size of the map
    [SerializeField] private Transform player; 
    public int width = 100;
    public int height = 100;

    // The seed for the random number generator
    public int seed = 0;

    // The scale of the noise
    public float noiseScale = 0.01f;

    // The threshold for the noise
    public float noiseThreshold = 0.3f;

    // The number of houses to place randomly
    public int houseCount = 20;

    // The tiles for the tilemap
    public Tile houseTile;
    public HashSet<Vector3Int> housePoses = new HashSet<Vector3Int>();
    public Tile emptyTile;
    public Tile obstacleTile;
    public Tile waterTile;

    // The tilemap for the map
    public Tilemap tilemap;

    // The 2D array of tile types
    private int[,] map;


    // Start is called before the first frame update
    private async void OnEnable() {
        tilemap.ClearAllTiles();
        // Generate the map
        Random.InitState(PlayerPrefs.GetInt("seed"));
        await GenerateMap();
    }

    // Generate the map
    private async Task GenerateMap() {
        // Initialize the map array
        map = new int[width, height];

        // Use the seed to initialize the random number generator
        seed = Random.Range(0, 1000000);
        Random.InitState(seed);
        PlayerPrefs.SetInt("seed", seed);

        // Generate the noise map
        GenerateNoiseMap();
        PlantRandomTrees();

        // Place the houses randomly
        PlaceHouses();

        // Update the tilemap
        UpdateTilemap();
    }

    // Generate the noise map
    private void GenerateNoiseMap() {
        // Loop through each cell in the map
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                // Calculate the noise value for the cell
                float noiseValue = Mathf.PerlinNoise(x * noiseScale, y * noiseScale);

                // Compare the noise value with the threshold
                if (noiseValue > noiseThreshold) {
                    // Set the cell to be empty
                    map[x, y] = (int)TileType.Empty;
                }
                else if(noiseValue <= 0.15f)
                {
                    map[x, y] = (int)TileType.Water;
                }
                else {
                    // Set the cell to be an obstacle
                    map[x, y] = (int)TileType.Obstacle;
                }
            }
        }
    }

    // Place the houses randomly
    private void PlaceHouses() {
        // Initialize the house counter to zero
        int houseCounter = 0;

        // Loop until the house counter reaches the house count
        while (houseCounter < houseCount) {
            // Choose a random cell
            int x = Random.Range(0, width);
            int y = Random.Range(0, height);

            // Check if the cell is empty
            if (map[x, y] == (int)TileType.Empty) {
                // Set the cell to be a house
                map[x, y] = (int)TileType.House;

                // Increment the house counter
                houseCounter++;
            }
        }
    }

    private void PlantRandomTrees()
    {
        int treeCounter = 0;

        // Loop until the house counter reaches the house count
        while (treeCounter < 200) {
            // Choose a random cell
            int x = Random.Range(0, width);
            int y = Random.Range(0, height);

            // Check if the cell is empty
            if (map[x, y] == (int)TileType.Empty) {
                // Set the cell to be a house
                map[x, y] = (int)TileType.House;

                // Increment the house counter
                treeCounter++;
            }
        }
    }

    // Update the tilemap
    private async void UpdateTilemap() {
        // Loop through each cell in the map
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                bool isHouse = false;
                // Get the tile type of the cell
                TileType tileType = (TileType)map[x, y];

                // Choose the tile for the tile type
                Tile tile = null;
                switch (tileType) {
                    case TileType.House:
                        tile = houseTile;
                        map[x, y] = (int)TileType.Empty;
                        isHouse = true;
                        break;
                    case TileType.Empty:
                        tile = emptyTile;
                        break;
                    case TileType.Obstacle:
                        tile = obstacleTile;
                        break;
                    case TileType.Water:
                        tile = waterTile;
                        break;
                }

                // Set the tile at the cell position
                Vector3Int position = new Vector3Int(x, y, 0);
                if(isHouse)
                    {housePoses.Add(position);}
                tilemap.SetTile(position, tile);
            }
            await Task.Delay(1);
        }
        SetPlayerPosition();
    }

    private async void SetPlayerPosition()
    {
        List<Vector3Int> convertedHashSet = new List<Vector3Int>(housePoses);
        Vector3 pos = convertedHashSet[Random.Range(0, housePoses.Count)];
        await GetComponent<StructGeneration>().GenerateWorld(map, housePoses);  
        player.position = new Vector3(pos.x + 0.5f, pos.y + 0.5f, 0);   
    }
}
