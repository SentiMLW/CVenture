using UnityEngine;
using UnityEngine.Tilemaps;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;

public class StructGeneration : MonoBehaviour {
    // The size of the world
    public static StructGeneration structGenInstance;
    public int worldWidth = 700;
    public int worldHeight = 700;

    // The size of the town
    public int townWidth = 10;
    public int townHeight = 10;

    // The number of towns to spawn randomly
    public int townCount = 10;

    // The tiles for the tilemap
    public Tile houseTile;
    [SerializeField] private GameObject manPref;
    private List<Man> allMan = new List<Man>();
    [SerializeField] private List<TownClass> allTowns = new List<TownClass>(); 
    [SerializeField] private int houseCount; 
    [SerializeField] private HashSet<Vector3Int> housePoses; 
    public Tile roadTile;
    public Tile grassTile;
    [SerializeField] private RuleTile borderTile; 

    // The tilemap for the world
    public Tilemap tilemap;
    public Tilemap borderMap;
    private int[,] townMap;

    // The 2D array of tile types
    private int[,] map;

    private bool canStep;

    // Generate the world
    public async Task GenerateWorld(int[,] _map, HashSet<Vector3Int> _housePoses) {
        // Initialize the map array
        structGenInstance = this;
        housePoses = _housePoses;
        map = _map;

        // Set the default tile type to be grass
        Debug.Log("sussyBake");

        // Spawn the towns randomly
        await SpawnTowns();
        Debug.Log("sussssss");

        // Update the tilemap
        await UpdateTilemap();
        Debug.Log("GenFinished Succccccccccksessfully");
    }

    // Spawn the towns randomly
    private async Task SpawnTowns() {
        // Initialize the town counter to zero
        int townCounter = 0;

        // Loop until the town counter reaches the town count
        while (townCounter < townCount) {
            // Choose a random position for the town
            int x = Random.Range(0, worldWidth - townWidth);
            int y = Random.Range(0, worldHeight - townHeight);

            // Check if the position is valid for spawning a town
            
                // Spawn the town at the position
            SpawnTown(x, y);

                // Increment the town counter
            townCounter++;
        }
    }

    // Spawn the town at the position
    async void SpawnTown(int x, int y) {
        // Generate the town map
        await GenerateTownMap();

        // Copy the town map to the world map
        for (int i = x; i < x + townWidth; i++) {
            for (int j = y; j < y + townHeight; j++) {
                map[i, j] = townMap[i - x, j - y];
                borderMap.SetTile(new Vector3Int(i, j, 0), borderTile);
            }
        }
    }

    // Generate the town map
    async Task GenerateTownMap() {
        // Initialize the town map array
        int[,] _townMap = new int[townWidth, townHeight];

        // Set the default tile type to be grass
        for (int x = 0; x < townWidth; x++) {
            for (int y = 0; y < townHeight; y++) {
                _townMap[x, y] = (int)TileType.Grass;
            }
        }

        // Place the houses randomly
        await PlaceHouses(_townMap);

        // Connect the houses with roads
        await ConnectHouses(_townMap);

        // Return the town map
        townMap = _townMap;
    }

    // Place the houses randomly
    private async Task PlaceHouses(int[,] townMap) {
        // Initialize the house counter to zero
        int houseCounter = 0;
        List<HouseBehaviour> houseBehs = new List<HouseBehaviour>();
        // Loop until the house counter reaches the house count
        while (houseCounter < houseCount) {
            // Choose a random cell
            int x = Random.Range(0, townWidth);
            int y = Random.Range(0, townHeight);

            // Check if the cell is valid for placing a house
            if (IsValidForHouse(townMap, x, y)) {
                // Set the cell to be a house
                townMap[x, y] = (int)TileType.House;
                Debug.Log($"sus{x}, {y}");

                // Increment the house counter
                houseCounter++;
            }
        }
    }

    // Check if the cell is valid for placing a house
    bool IsValidForHouse(int[,] townMap, int x, int y) {
        // Check if the cell is already occupied
        if (townMap[x, y] != (int)TileType.Grass) {
            return false;
        }

        // Check if the cell has enough distance from other houses
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                // Check if the cell is within the town bounds
                if (i >= 0 && i < townWidth && j >= 0 && j < townHeight) {
                    // Check if the cell is a house
                    if (townMap[i, j] == (int)TileType.House) {
                        return false;
                    }
                }
            }
        }

        // Return true if the cell is valid
        return true;
    }

    // Connect the houses with roads
    private async Task ConnectHouses(int[,] townMap) {
        // Loop through each cell in the town map
        for (int x = 0; x < townWidth; x++) {
            for (int y = 0; y < townHeight; y++) {
                // Check if the cell is a house
                if (townMap[x, y] == (int)TileType.House) {
                    // Connect the house to the nearest house on the right
                    ConnectToRight(townMap, x, y);

                    // Connect the house to the nearest house on the top
                    ConnectToTop(townMap, x, y);
                }
            }
        }
    }

    // Connect the house to the nearest house on the right
    private async Task ConnectToRight(int[,] townMap, int x, int y) {
        // Initialize the distance to the nearest house on the right
        int distance = int.MaxValue;

        // Loop through the cells on the right of the house
        for (int i = x + 1; i < townWidth; i++) {
            // Check if the cell is a house
            if (townMap[i, y] == (int)TileType.House) {
                // Calculate the distance to the house
                distance = i - x;

                // Break the loop
                break;
            }
        }

        // Check if the distance is valid
        if (distance > 0 && distance < int.MaxValue) {
            // Loop through the cells between the houses
            for (int i = x + 1; i < x + distance; i++) {
                // Set the cell to be a road
                townMap[i, y] = (int)TileType.Road;
            }
        }
    }

    // Connect the house to the nearest house on the top
    private async Task ConnectToTop(int[,] townMap, int x, int y) {
        // Initialize the distance to the nearest house on the top
        int distance = int.MaxValue;

        // Loop through the cells on the top of the house
        for (int j = y + 1; j < townHeight; j++) {
            // Check if the cell is a house
            if (townMap[x, j] == (int)TileType.House) {
                // Calculate the distance to the house
                distance = j - y;

                // Break the loop
                break;
            }
        }

        // Check if the distance is valid
        if (distance > 0 && distance < int.MaxValue) {
            // Loop through the cells between the houses
            for (int j = y + 1; j < y + distance; j++) {
                // Set the cell to be a road
                townMap[x, j] = (int)TileType.Road;
            }
        }
    }

    // Update the tilemap
    private async Task UpdateTilemap() {
        // Loop through each cell in the world map
        for (int x = 0; x < worldWidth; x++) {
            for (int y = 0; y < worldHeight; y++) {
                // Get the tile type of the cell
                TileType tileType = (TileType)map[x, y];

                // Choose the tile for the tile type
                TileBase tile = null;
                Vector3Int position = new Vector3Int(x, y, 0);
                switch (tileType) {
                    case TileType.House:
                        tile = houseTile;             
                        housePoses.Add(position);
                        break;
                    case TileType.Road:
                        tile = roadTile;
                        break;
                    default:
                        tile = null;
                        break;
                }                // Set the tile at the cell position
                if(tile != null)
                    {tilemap.SetTile(position, tile);}
            }
            await Task.Delay(1);
        }
        SetManInHouses();
    }

    private async void SetManInHouses()
    {
        bool isMale = true;
        foreach(Vector3Int housePos in housePoses)
        {
            GameObject man = Instantiate(manPref, housePos + new Vector3(0.5f, 0.5f, 0), Quaternion.identity);
            Man manComp = man.GetComponentInChildren<Man>();
            manComp.Init(isMale, false, tilemap);
            isMale = !isMale;
            allMan.Add(manComp);
            await Task.Delay(1);
        }
    }

    public void AddManToAllMen(Man man)
    {
        allMan.Add(man);
    }

    public void AllManStep()
    {
        List<Man> allManCopy = new List<Man>(allMan);
        foreach(Man man in allManCopy)
        {
            man.Step();
        }
    }
}

public enum TileType {
    House,
    Road,
    Grass,
    Border,
    Empty,
    Obstacle,
    Water
}

public class TownClass{
    public List<HouseBehaviour> houseBehList = new List<HouseBehaviour>();
}